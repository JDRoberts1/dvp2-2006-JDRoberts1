﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RobertsJeanai_CustomApp
{
    class Menu
    {
        public static void LoginMenuList()
        {
            List<string> loginList = new List<string>();
            loginList.Add("Login");
            loginList.Add("Create new user");
            loginList.Add("Exit");

            // display menu list to console
            DisplayMenuList(loginList);
        }

        public static void MainMenuList()
        {
            List<string> mainMenu = new List<string>();
            mainMenu.Add("View Tasks");
            mainMenu.Add("View Activy Log");
            mainMenu.Add("Log out");


            // display menu list to console
            DisplayMenuList(mainMenu);
        }

        public static void ViewTaskList()
        {
            // zadd menu options to the list
            List<string> taskMenu = new List<string>();
            taskMenu.Add("View all incomplete tasks");
            taskMenu.Add("Update a task");
            taskMenu.Add("Create new task");

            // display menu list to console
            DisplayMenuList(taskMenu);
        }

        public static void UpdateSubMenu()
        {
            
            List<string> updateTaskList = new List<string>();
            updateTaskList.Add("Change status");
            updateTaskList.Add("Update time spent");
            updateTaskList.Add("Update Category");
            updateTaskList.Add("Delete activity");

            DisplayMenuList(updateTaskList);
        }

        public static void UpdateStatus()
        {
            List<string> updateStatusList = new List<string>();
            updateStatusList.Add("Mark as NOT started");
            updateStatusList.Add("Mark as In Progress");
            updateStatusList.Add("Mark as Complete");

            DisplayMenuList(updateStatusList);
        }

        public static void Timeist()
        {
            
            string query = "SELECT * FROM timeUsedList;";

            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            int counter = 1;
            int minutes = 15;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                Console.Write($" {counter++}: {minutes+15} = ");
                Console.Write($"{row["timeSpent"].ToString()}");
                Console.WriteLine();
            }
        }

        

        public static void userDate()
        {

            string query = "Select * from datesList;";

            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            int counter = 1;

            // output to console
            foreach (DataRow row in rows)
            {
                Console.WriteLine(counter++ + ": ");
                string date = row["dates"].ToString();
                date.PadLeft(10);
                Console.WriteLine(date);
                Console.WriteLine();
            }
        }

        public static void catergoryList()
        {

            string query = "SELECT * FROM categoryList;";

            DataTable data = Database.DatabaseConnection(query);
            List<string> categoryList = new List<string>();

            categoryList.Add("Work");
            categoryList.Add("School");
            categoryList.Add("Hobby");

            DisplayMenuList(categoryList);
        }

        public static void ActivityLogList()
        {
            List<string> activityMenu = new List<string>();
            activityMenu.Add("View all unstarted tasks");
            activityMenu.Add("View all in progress tasks");
            activityMenu.Add("View completed tasks");
            activityMenu.Add("View tasks in selected category");
            

            // display menu list to console
            DisplayMenuList(activityMenu);
        }

       
        
        // display menu list to console
        public static void DisplayMenuList(List<string> listName)
        {
            for (int counter = 0; counter < listName.Count; counter++)
            {
                Console.WriteLine($"{counter + 1}: {listName[counter]}");
            }
        }


        public static int CreateOrSelectDate(int userID, int selection)
        {

            if (selection == 1)
            {
                Menu.userDate();
                Console.WriteLine("Please select a date");
                int dateChoice = Validation.GetInt();

                return dateChoice;
            }
            else
            {
                Console.WriteLine("Please enter a date in format yyyyy-dd-mm");
                string dateString = Validation.IsEmpty();

                Database.CreateNewDate(dateString, userID);

                Menu.userDate();
                Console.WriteLine("Please select a date");
                int dateChoice = Validation.GetInt();

                return dateChoice;
            }
        }



        public static int CreateOrSelectActivity(int userID, int selection)
        {

            if (selection == 1)
            {
                Database.SeeUserTask(userID);
                Console.WriteLine("Please select an activity");
                int dateChoice = Validation.GetInt();

                return dateChoice;
            }
            else
            {
                Console.WriteLine("Please enter task name");
                string taskString = Validation.IsEmpty();

                Database.CreateNewActivity(taskString, userID);

                Database.SeeUserTask(userID);
                Console.WriteLine("Please select an activity");

                int activityChoice = Validation.GetInt();

                return activityChoice;
            }
        }

        public static int SelectStatus()
        {
            Console.WriteLine("1: Mark as UNSTARTED");
            Console.WriteLine("2. MArk as IN PROGRESS");

            int choice = Validation.TwoOptionValdation();

            return choice;
        }
    }
}
