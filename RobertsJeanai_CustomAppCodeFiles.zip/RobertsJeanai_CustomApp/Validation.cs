﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobertsJeanai_CustomApp
{

    // Validation class to validate all input being recieved
    class Validation
    {
        public static int GetInt()
        {
            string input = Console.ReadLine();
            int validatedInt;

            while (!(int.TryParse(input, out validatedInt)))
            {
                Console.WriteLine("Please enter a valid value");
                input = Console.ReadLine();
            }

            return validatedInt;
        }

        public static int SelectionValidation()
        {
            Console.WriteLine("Enter 0 to view more data");
            Console.WriteLine("Enter 1 to return to Tracked data menu");

            string input = Console.ReadLine();
            int validatedInt;

            while (!(int.TryParse(input, out validatedInt)) || (validatedInt < 0 || validatedInt > 1))
            {
                Console.WriteLine("Please enter a valid value");
                input = Console.ReadLine();
            }

            return validatedInt;
        }

        public static double GetDouble(string input)
        {
            
            double validatedDouble;
            
            while(!(double.TryParse(input, out validatedDouble)))
            {
                Console.WriteLine("Please enter a valid value");
                input = Console.ReadLine();
            }

            return validatedDouble;
        }

        public static decimal GetDecimal()
        {
            string input = Console.ReadLine();
            decimal validatedDecimal;

            while (!(decimal.TryParse(input, out validatedDecimal)))
            {
                Console.WriteLine("No rating");

            }

            return validatedDecimal;
        }

        public static string IsEmpty()
        {
            string input = Console.ReadLine().ToLower();

            while (string.IsNullOrWhiteSpace(input))
            {
                Console.WriteLine("Please do not leave blank");
                input = Console.ReadLine();
            }

            return input;
        }

        public static void PressToContinue()
        {
            Console.WriteLine("Press any key to continue ");
            Console.ReadKey();
        }

        public static void GoBack()
        {
            Console.WriteLine("Enter 0 to return to the main menu");
            Console.ReadKey();
        }

        public static int ValidatedAnswer()
        {

            string input = Console.ReadLine();
            int validatedInt;

            while (!(int.TryParse(input, out validatedInt)) || (validatedInt < 0 || validatedInt > 1))
            {
                Console.WriteLine("Please enter a valid value");
                input = Console.ReadLine();
            }

            return validatedInt;

            
        }

        public static void PleaseSelect()
        {
            Console.WriteLine("Please select an option or 0 to return");
        }

        public static int TwoOptionValdation()
        {
            string inputString = IsEmpty();
            int input;

            while (!(int.TryParse(inputString, out input)) || (input < 0 || input > 2))
            {
                Console.WriteLine("Please enter a valid value");
                inputString = Console.ReadLine();
            }

            return input;

        }
    }
}
