﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace RobertsJeanai_CustomApp
{
    public class Database
    {
        MySqlConnection _conn = null;
        

        public static DataTable DatabaseConnection(string query)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.QueryDB(query);

            instance._conn.Close();

            return data;

        }

        public static DataTable LoginToDB(int userId, string password)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();


            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.LoginFuction(userId, password);

            instance._conn.Close();

            return data;
            
        }

        public static void ActivityViewer(int userId)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();


            // inside the parethese SELECT the columns of data to be returned.
            instance.FindActivity(userId);

            instance._conn.Close();
        }

       
        

        public static void NewUser(int userID, string firstName, string lastName, string username, string password)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            instance.CreateNewUser(userID, firstName, lastName, username, password);

            instance._conn.Close();

            Validation.PressToContinue();

        }

        public static void CreateNewActivity(string taskname, int userId)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            instance.InsertNewTask(taskname, userId);

            instance._conn.Close();

        }
        public static void CreateNewDate(string date, int userId)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            instance.InsertNewDate(date, userId);

            instance._conn.Close();
        }

        public static void CreateNewTask(int userId, int date, int status, int task_category, int task_activity)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            instance.CreateTask(userId, date, status, task_category, task_activity) ;

            instance._conn.Close();

            Validation.PressToContinue();

        }

        public static DataTable SearchLogs(string query, int userID)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.ViewTask(query, userID);

            instance._conn.Close();

            return data;

        }

        public static DataTable SearchActivity(int input, int userID, int taskID)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.ViewActivity(input, userID, taskID);

            instance._conn.Close();

            return data;
        }

        public static void SeeUserTask(int userID)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            instance.UserTaskList(userID);

            instance._conn.Close();

            Validation.PressToContinue();
        }

        public static void UpdateUserTask(int input, int userID, int value)
        {
            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            instance.UpdateTask(input, userID, value);

            instance._conn.Close();
            Validation.PressToContinue();
        }

       
        void Connect()
        {
            
            // Connection string
            BuildConnection();

            // try to connect
            try
            {
                // uses member variable
                _conn.Open();
                Console.WriteLine(" ");
            }
            catch (MySqlException e)
            {
                string msg = "";
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                            break;
                        }
                    case 1042:
                        {
                            msg = "Cant resolve host address.\n" + _conn.ConnectionString;
                            break;
                        }
                    case 1045:
                        {
                            msg = "invalid username/password";
                            break;
                        }
                    default:
                        {
                            msg = e.ToString();
                            break;
                        }

                }

                // display the exception message outsifde the switch statement 
                Console.WriteLine(msg);
            }
        }

        void BuildConnection()
        {
            string ip = "";

            // varieties of this statement
            // forwardslash : c:\\VFW\connect.txt
            // @ symbol in front : @"c:/VFW/connect.txt"
            using (StreamReader sr = new StreamReader("C:/VFW/connect.txt"))
            {
                // set the ip variable to a readline
                // returns the ip address
                ip = sr.ReadLine();
            }

            // build the string
            // server gets ip
            // hard coded values
            string conString = $"Server={ip};";
            conString += "user id=dbsAdmin;";
            conString += "pwd=password;";
            conString += "database=MDV229_CustomApp;";
            // the port
            conString += "port=8889;";

            _conn.ConnectionString = conString;
        }

        DataTable QueryDB(string query)
        {
            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;


        }

        DataTable ViewTask(string query, int userID)
        {
            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userID });

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;

        }

        void UserTaskList(int userID)
        {

            string query = "Select * FROM taskList;";
            
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userID });

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            DataRowCollection rows = data.Rows;
            int counter = 1;

            foreach (DataRow row in rows)
            {
                Console.WriteLine(counter++ + ": ");
                Console.WriteLine(row["taskName"].ToString());
                Console.WriteLine();
            }

        }

        void FindActivity(int userID)
        {
            
            string insertQuery = $"Select Distinct(task_Activity), taskList.taskName FROM task_Log Join taskList on task_Log.task_Activity = taskList.taskList_ID Where userID = @userID;";

            MySqlCommand cmd = new MySqlCommand(insertQuery, _conn);

            cmd.Parameters.AddWithValue("@userID", userID);

            MySqlDataReader rdr = cmd.ExecuteReader();

            if (rdr.HasRows)
            {
              
                rdr.Read();
                int task_ActivityID = Convert.ToInt32(rdr["task_Activity"].ToString());
                string activityName = rdr["taskName"].ToString();

                rdr.Close();

                Console.WriteLine($"{task_ActivityID} : {activityName}");

            }
            else
            {
                Console.WriteLine("No activity found");
                
            }
        }
        

        void CreateNewUser(int userID, string firstName, string lastName, string username, string password)
        {
            // request firstName, lastLame, username, password 
            string insertQuery = $"INSERT INTO userLog (userId, firstName, lastName,  username, password) Values (@userId, @firstName, @lastName, @username, @password);";
            MySqlCommand cmd = new MySqlCommand(insertQuery, _conn);

            cmd.Parameters.AddWithValue("@userID", userID);
            cmd.Parameters.AddWithValue("@firstName", firstName);
            cmd.Parameters.AddWithValue("@lastName", lastName);
            cmd.Parameters.AddWithValue("@username", username);
            cmd.Parameters.AddWithValue("@password", password);

            MySqlDataReader rdr = cmd.ExecuteReader();

            rdr.Read();

            rdr.Close();

            Console.WriteLine("User successfully created");
        }

        void InsertNewTask(string taskName, int userId)
        {
            string query = "Insert Into taskList (taskName) Values (@taskName)";
            
            MySqlCommand cmd = new MySqlCommand(query, _conn);

            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@taskName", taskName);

            MySqlDataReader rdr = cmd.ExecuteReader();

            rdr.Read();

            Console.WriteLine("Date added");

            rdr.Close();
        }

        void CreateTask(int userId, int date, int status, int task_category, int task_activity)
        {
            string query = "Insert INTO task_Log(userID, date, status, task_category, task_activity) Values(@userID, @date, @status, @task_category, @task_activity);";
            
            MySqlCommand cmd = new MySqlCommand(query, _conn);

            cmd.Parameters.AddWithValue("@userId", userId);
            cmd.Parameters.AddWithValue("@date", date);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Parameters.AddWithValue("@task_category", task_category);
            cmd.Parameters.AddWithValue("@task_activity", task_activity);
            

            MySqlDataReader rdr = cmd.ExecuteReader();

            rdr.Read();

            rdr.Close();

        }

        void InsertNewDate(string dates, int userId)
        {
            string query = "Insert Into datesList (dates) Values (@dates);";

            MySqlCommand cmd = new MySqlCommand(query, _conn);

            cmd.Parameters.AddWithValue("@dates", dates);

            MySqlDataReader rdr = cmd.ExecuteReader();

            rdr.Read();

            Console.WriteLine("Date added");

            rdr.Close();
        }


        

        DataTable LoginFuction(int userId, string password)
        {
            string query = "SELECT userId, firstName, lastName, username, password from userLog where userId = @userId and password = @password;";

            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userId });
            adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@password", Value = password });

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;

        }

        void UpdateTask(int input, int taskID, int value)
        {

            MySqlDataAdapter adapter;
            string query;

            
            if (input == 1)
            {
                
                query = "Update task_Log Set status = @status where task_ID = @task_ID;";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@status", Value = value });
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@task_ID", Value = taskID });
            }
            else if (input == 2)
            {
                query = "Update task_Log Set time_spent = @time_spent where task_ID = @task_ID;";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@time_spent", Value = value });
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@task_ID", Value = taskID });

            }
            else if(input == 3)
            {
                query = "Update task_Log Set task_Category = @task_Category where task_ID = @task_ID;";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@task_Category", Value = value });
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@task_ID", Value = taskID });
            }
            else
            {
                query = "Delete from task_Log where task_ID = @task_ID";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@task_ID", Value = taskID });
            }

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            Console.WriteLine("Task updated!");
            Console.Clear();
        }

        DataTable ViewActivity(int input, int userID, int value)
        {

            MySqlDataAdapter adapter;
            string query;
            DataTable data = new DataTable();

            if (input == 1)
            {
                // view all tasks
                query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userId = @userId";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userID });

                data = new DataTable();
                // tell how to execute the command
                adapter.SelectCommand.CommandType = CommandType.Text;

                // executes the query and puts the data retuned in the data table
                adapter.Fill(data);

                return data;

            }
            else if (input == 2)
            {
                // view completed tasks
                query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userId = @userId AND Status = 3;";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userID });

                data = new DataTable();
                // tell how to execute the command
                adapter.SelectCommand.CommandType = CommandType.Text;

                // executes the query and puts the data retuned in the data table
                adapter.Fill(data);

                return data;

            }
            else if (input == 3)
            {
                // view tasks in category
                query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userId = @userId and Task_Log.task_category = @Task_Log.task_category;";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userID });
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@Task_Log.task_category", Value = value });

                data = new DataTable();

                // tell how to execute the command
                adapter.SelectCommand.CommandType = CommandType.Text;

                // executes the query and puts the data retuned in the data table
                adapter.Fill(data);

                return data;
            }
            else
            {
                // view certain tasks
                query = "SELECT task_ID, userLog.username, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join userLog on task_Log.userID = userLog.UserId Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userLog.userId = @userLog.userId AND task_ID = @task_ID";
                adapter = new MySqlDataAdapter(query, _conn);
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@userId", Value = userID });
                adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@task_ID", Value = value });

                data = new DataTable();
                // tell how to execute the command
                adapter.SelectCommand.CommandType = CommandType.Text;

                // executes the query and puts the data retuned in the data table
                adapter.Fill(data);

                return data;

            }

        }
    }
}
