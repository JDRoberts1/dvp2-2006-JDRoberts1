﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobertsJeanai_CustomApp
{
    class Calculations
    {
    }
}
