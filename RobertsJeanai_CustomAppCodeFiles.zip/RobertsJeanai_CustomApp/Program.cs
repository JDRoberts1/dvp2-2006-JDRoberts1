﻿using System;

namespace RobertsJeanai_CustomApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Welcome to U-Track");
            bool programIsRunning = true;

            while (programIsRunning)
            {
                // request user to log in
                
                Menu.LoginMenuList();
                int userInput = Validation.GetInt();

                switch (userInput)
                {
                    case 1:
                        {
                            // Log user in
                            Console.Clear();

                            Submenu.LogInSubmenu();
                            
                            Console.Clear();
                        }
                        break;
                    case 2:
                        {
                            // Create user
                            Console.Clear();
                            
                            Submenu.CreateAUser();
                            
                            Console.Clear();
                        }
                        break;
                    case 3:
                        {
                            // exit program
                            Console.Clear();
                            programIsRunning = false;
                        }
                        break;
                }
            }
        }
    }
}
