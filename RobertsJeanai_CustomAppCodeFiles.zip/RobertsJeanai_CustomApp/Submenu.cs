﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RobertsJeanai_CustomApp
{
    class Submenu
    {
        public static void LogInSubmenu()
        {
            Console.Clear();

            bool loginisRunning = true;

            while (loginisRunning)
            {
                
                // log the user in
                Console.WriteLine("Please enter user ID");
                int userID = Validation.GetInt();

                Console.WriteLine("Please enter password");
                string userPassword = Validation.IsEmpty();

                Console.Clear();

                DataTable data = Database.LoginToDB(userID, userPassword);

                DataRowCollection rows = data.Rows;

                // validate that the user does exist
                foreach (DataRow row in rows)
                {
                    string userName = row["username"].ToString();
                    string Password = row["password"].ToString();

                    if (userName != "" || Password != "")
                    {
                        userID = Convert.ToInt32(row["userId"].ToString());
                        
                        string Firstname = row["firstName"].ToString();
                        string Lastname = row["lastName"].ToString();

                        Console.Clear();

                        bool mainMenuIsRunning = true;
                        
                        // welcome user
                        while (mainMenuIsRunning)
                        {
                            // select View tasks, View activity log and Exit
                            Console.WriteLine($"Welcome {userName}");
                            Menu.MainMenuList();

                            int userChoice = Validation.GetInt();

                            bool subMain = true;
                            while (subMain)
                            {
                                if (userChoice > 4)
                                {
                                    // input graeter than 3 is invalid because there are only 3 main menu options
                                    Console.WriteLine("Please select a valid");
                                }
                                else if (userChoice == 3)
                                {
                                    // Log out of program
                                    subMain = false;
                                    mainMenuIsRunning = false;
                                    loginisRunning = false;
                                }
                                else
                                {
                                    // Main Menu
                                    if (userChoice == 1)
                                    {
                                        // view tasks menu
                                        Console.Clear();
                                        Console.WriteLine("What would you like to do? ");
                                        Menu.ViewTaskList();
                                        Console.WriteLine("Enter 0 to return to main menu");
                                        int input = Validation.GetInt();

                                        if(input == 0)
                                        {
                                            Console.Clear();
                                            subMain = false;

                                        }
                                        else if(input == 1)
                                        {
                                            // view incomplete tasks
                                            Console.Clear();
                                            IncompleteTasks(userID);
                                            Validation.PressToContinue();
                                            Console.Clear();

                                        }
                                        else if (input == 2)
                                        {
                                            // update task
                                            Console.Clear();
                                            
                                            IncompleteTasks(userID);

                                            Console.WriteLine("Please select a task to update");
                                            Console.WriteLine("Enter 0 to return to main menu");
                                            int taskID = Validation.GetInt();

                                            if (taskID != 0)
                                            {
                                                UpdateTask(userID, taskID);
                                                Console.WriteLine("Task updated!");
                                            }
                                            else
                                            {
                                                subMain = false;
                                            }
                                        }
                                        else if (input == 3)
                                        {
                                            // create a task
                                            Console.Clear();
                                            CreateTask(userID);

                                            Validation.PressToContinue();
                                            Console.Clear();
                                        }
                                        else
                                        {
                                            Console.WriteLine("Please select a valid option");
                                        }
                                    }
                                    else
                                    {
                                        // view activity menu
                                        Console.Clear();
                                        Console.WriteLine("What would you like view? ");
                                        Menu.ActivityLogList();
                                        Console.WriteLine("Enter 0 to return to main menu");
                                        int input = Validation.GetInt();

                                        // return to menu
                                        if(input == 0)
                                        {
                                            Console.Clear();
                                            subMain = false;
                                        }
                                        else if (input == 1)
                                        {
                                            // display all unstarted tasks
                                            ViewUnstarted(userID);

                                            Validation.PressToContinue();
                                            Console.Clear();
                                        }
                                        else if (input == 2)
                                        {
                                            // display all tasks currectly inj progress
                                            ViewInProgress(userID);

                                            Validation.PressToContinue();
                                            Console.Clear();
                                        }
                                        else if (input == 3)
                                        {
                                            // view all completed tasks 
                                            ViewCompleted(userID);

                                            Validation.PressToContinue();
                                            Console.Clear();

                                        }
                                        else if (input == 4)
                                        {
                                            // view tasks by category
                                            Console.WriteLine("Which task category would you like to view?");
                                            Menu.catergoryList();
                                            Console.WriteLine("Enter 0 to return to main menu");
                                            int categorChoice = Validation.GetInt();

                                            if(categorChoice == 0)
                                            {
                                                Console.Clear();
                                                subMain = false;
                                            }
                                            else if (categorChoice == 1)
                                            {
                                                // view all tasks categorized as work
                                                ViewWork(userID);
                                            }
                                            else if (categorChoice == 2)
                                            {
                                                // view all tasks that are catergorized as school
                                                ViewSchool(userID);
                                            }
                                            else if (categorChoice == 3)
                                            {
                                                // view all tasks categorized as hobby
                                                ViewHobby(userID);
                                            }
                                            else
                                            {
                                                Console.WriteLine("Please select a valid option");
                                            }

                                            Validation.PressToContinue();
                                            Console.Clear();
                                        }
                                        else
                                        {
                                            Console.WriteLine("Please select a valid option");
                                        }


                                    }

                                    
                                }
                            }
                        }
                        
                    }
                    else
                    {
                        Console.WriteLine("Login failed, Please try again");
                    }
                }
            }

           
        }

        public static void CreateAUser()
        {
            Console.Clear();
            bool createUserIsRunning = true;
            while (createUserIsRunning)
            {
                // Create user
                // request first name, last name, username, password 
                Console.WriteLine("Welcome new user");
                Console.WriteLine();
                
                Console.WriteLine("Please enter a User ID");
                Console.WriteLine("Press 0 to return to Login Menu");
                int userID = Validation.GetInt();

                if (userID != 0)
                {
                    bool nameIsRunning = true;

                    while (nameIsRunning)
                    {
                        Console.WriteLine("Please enter your first name: ");
                        Console.WriteLine("Press 0 to go back");
                        string userFirst = Validation.IsEmpty();

                        if(userFirst != "0")
                        {
                            bool lastIsRunning = true;

                            while (lastIsRunning)
                            {
                                Console.WriteLine("Please enter your last name: ");
                                Console.WriteLine("Press 0 to go back");
                                string userLast = Validation.IsEmpty();

                                if (userLast != "0")
                                {
                                    bool userNamIsRunning = true;
                                    while (userNamIsRunning)
                                    {
                                        Console.WriteLine("Please enter a username (MAX 25 Characters): ");
                                        Console.WriteLine("Press 0 to go back");
                                        string userName = Validation.IsEmpty();

                                        if (userFirst != "0")
                                        {
                                            bool passwordIsRunning = true;

                                            while (passwordIsRunning)
                                            {
                                                Console.WriteLine("Please enter a password (MAX 25 Characters): ");
                                                Console.WriteLine("Press 0 to go back");
                                                string password = Validation.IsEmpty();

                                                if(password != "0")
                                                {
                                                    Database.NewUser(userID, userName, userLast, userName, password);
                                                    LogInSubmenu();

                                                    passwordIsRunning = false;
                                                    userNamIsRunning = false;
                                                    lastIsRunning = false;
                                                    nameIsRunning = false;
                                                    createUserIsRunning = false;
                                                }
                                                else
                                                {
                                                    passwordIsRunning = false;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            userNamIsRunning = false;
                                        }
                                    }
                                }
                                else
                                {
                                    lastIsRunning = false;
                                }
                            }
                        }
                        else
                        {
                            nameIsRunning = false;
                        }

                    }
                }
                else
                {
                    createUserIsRunning = false;
                }
            }

        }

       
        public static void IncompleteTasks(int userID)
        {
            // View all incomplete tasks
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id where status != 3 and userId = @userId;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                int taskID = Convert.ToInt32(row["task_ID"].ToString());
                string date = row["dates"].ToString();
                date.PadLeft(10);
                string statusName = row["statusName"].ToString();
                string categoryName = row["categoryName"].ToString();
                string taskName = row["taskName"].ToString();

                Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName}");
            }

        }

        public static void ViewUnstarted(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id where userId = @userId and status = 1;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                int taskID = Convert.ToInt32(row["task_ID"].ToString());
                string date = row["dates"].ToString();
                date.PadLeft(10);
                string statusName = row["statusName"].ToString();
                string categoryName = row["categoryName"].ToString();
                string taskName = row["taskName"].ToString();

                Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : No time available");
                Console.WriteLine();



            }
        }

        public static void ViewInProgress(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userId = @userId and status = 2;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                string timeString = row["timeSpent"].ToString();
                
                if (timeString == " ")
                {
                    int taskID = Convert.ToInt32(row["task_ID"].ToString());
                    string date = row["dates"].ToString();
                    date.PadLeft(10);
                    string statusName = row["statusName"].ToString();
                    string categoryName = row["categoryName"].ToString();
                    string taskName = row["taskName"].ToString();

                    Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : No time available");
                    Console.WriteLine();
                }
                else
                {
                    int taskID = Convert.ToInt32(row["task_ID"].ToString());
                    string date = row["dates"].ToString();
                    date.PadLeft(10);
                    string statusName = row["statusName"].ToString();
                    string categoryName = row["categoryName"].ToString();
                    string taskName = row["taskName"].ToString();
                    double timeSpent = Convert.ToDouble(row["timeSpent"].ToString());
                    Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : {timeSpent}");
                    Console.WriteLine();
                }
            }
        }

        public static void ViewCompleted(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userId = @userId and status = 3;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                string timeString = row["timeSpent"].ToString();

                if (timeString == " ")
                {
                    int taskID = Convert.ToInt32(row["task_ID"].ToString());
                    string date = row["dates"].ToString();
                    date.PadLeft(10);
                    string statusName = row["statusName"].ToString();
                    string categoryName = row["categoryName"].ToString();
                    string taskName = row["taskName"].ToString();

                    Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : No time available");
                    Console.WriteLine();
                }
                else
                {
                    int taskID = Convert.ToInt32(row["task_ID"].ToString());
                    string date = row["dates"].ToString();
                    date.PadLeft(10);
                    string statusName = row["statusName"].ToString();
                    string categoryName = row["categoryName"].ToString();
                    string taskName = row["taskName"].ToString();
                    double timeSpent = Convert.ToDouble(row["timeSpent"].ToString());
                    Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : {timeSpent}");
                    Console.WriteLine();
                }
            }
        }

        public static void ViewAll(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName, timeUsedList.timeSpent from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id Join timeUsedList ON task_Log.time_Spent = timeUsedList.timeUsed_id where userId = @userId;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                string timeString = row["timeSpent"].ToString();
                int taskID = Convert.ToInt32(row["task_ID"].ToString());
                string date = row["dates"].ToString();
                date.PadLeft(10);
                string statusName = row["statusName"].ToString();
                string categoryName = row["categoryName"].ToString();
                string taskName = row["taskName"].ToString();

                if (timeString == " ")
                {
                    
                    Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : No time available");
                    Console.WriteLine();
                }
                else
                {
                    
                    double timeSpent = Convert.ToDouble(row["timeSpent"].ToString());
                    Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName} Time : {timeSpent}");
                    Console.WriteLine();
                }
            }
        }

        public static void ViewWork(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id where userId = @userId and Task_Log.task_category = 1 Order By statusName;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
               
                int taskID = Convert.ToInt32(row["task_ID"].ToString());
                string date = row["dates"].ToString();
                string statusName = row["statusName"].ToString();
                string categoryName = row["categoryName"].ToString();
                string taskName = row["taskName"].ToString();

                Console.WriteLine($"TaskID: {taskID} Date: {date.PadRight(5)} Status: {statusName} Task Category: {categoryName} Task: {taskName}");
                Console.WriteLine();
            }
        }

        public static void ViewSchool(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id where userId = @userId and Task_Log.task_category = 2 Order By statusName;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                
                int taskID = Convert.ToInt32(row["task_ID"].ToString());
                string date = row["dates"].ToString();
                date.PadLeft(10);
                string statusName = row["statusName"].ToString();
                string categoryName = row["categoryName"].ToString();
                string taskName = row["taskName"].ToString();

                Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName}");
                Console.WriteLine();
            }
        }

        public static void ViewHobby(int userID)
        {
            string query = "SELECT task_ID, datesList.dates, statusList.statusName, categoryList.categoryName, taskList.taskName from task_Log Join datesList on task_Log.date = datesList.datesList_id JOIN statusList on task_Log.Status = statusList.statusList_id Join categoryList on task_Log.task_Category = categoryList.categoryList_id Join taskList ON task_Log.task_Activity = taskList.taskList_id where userId = @userId and Task_Log.task_category = 3 Order By statusName;";
            DataTable data = Database.SearchLogs(query, userID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                
                int taskID = Convert.ToInt32(row["task_ID"].ToString());
                string date = row["dates"].ToString();
                date.PadLeft(10);
                string statusName = row["statusName"].ToString();
                string categoryName = row["categoryName"].ToString();
                string taskName = row["taskName"].ToString();

                Console.WriteLine($"TaskID: {taskID} Date: {date} Status: {statusName} Task Category: {categoryName} Task: {taskName}");
                Console.WriteLine();
            }
        }

        public static void UpdateTask(int userId, int taskID)
        {
            
            bool updateSubMenuIsRunning = true;

            
            int selection;

            while (updateSubMenuIsRunning)
            {
                // Update a task
                

                Console.WriteLine("What updates would you like to make");

                
                Menu.UpdateSubMenu();
                Console.WriteLine("Press 0 to return to the menu");

                int userInput = Validation.GetInt();


                switch (userInput)
                {
                    case 0:
                        {
                            updateSubMenuIsRunning = false;
                        }
                        break;
                    case 1:
                        {
                            Console.WriteLine("What would you like to update the status to?");
                            Menu.UpdateStatus();
                            Console.WriteLine("Press 0 to return to the menu");
                            selection = Validation.GetInt();

                            if (selection == 0)
                            {
                                updateSubMenuIsRunning = false;
                            }
                            else
                            {
                                Database.UpdateUserTask(userInput, taskID, selection);
                                updateSubMenuIsRunning = false;
                            }

                            
                        }
                        break;
                    case 2:
                        {
                            Console.WriteLine("How much time was spent on this tasks (1. 15 minutes = .25) (1 = .25 - 96 = 24 hrs = 8");
                            Menu.Timeist();
                            Validation.PleaseSelect();
                            selection = Validation.GetInt();

                            if (selection > 96)
                            {
                                Console.WriteLine("Please select a valid option");
                            }
                            else if (selection == 0)
                            {
                                updateSubMenuIsRunning = false;
                            }
                            else
                            {
                                Database.UpdateUserTask(userInput, taskID, selection);
                                updateSubMenuIsRunning = false;
                            }

                        }
                        break;
                    case 3:
                        {
                            Console.WriteLine("What caregory would you like to update the task to?");
                            Menu.catergoryList();
                            Validation.PleaseSelect();
                            selection = Validation.GetInt();

                            if (selection > 3)
                            {
                                Console.WriteLine("Please select a valid option");
                            }
                            else if(selection == 0)
                            {
                                updateSubMenuIsRunning = false;
                            }
                            else
                            {
                                Database.UpdateUserTask(userInput, taskID, selection);
                                updateSubMenuIsRunning = false;
                            }
                        }
                        break;
                    case 4:
                        {
                            Console.WriteLine("Are you sure you would like to delete this task?");
                            Console.WriteLine("Enter 0 to return or 1 to contiunue");
                            int userEnter = Validation.GetInt();

                            if (userEnter == 0)
                            {
                                updateSubMenuIsRunning = false;
                            }
                            else if (userEnter == 1)
                            {
                                selection = 0;
                                Database.UpdateUserTask(userInput, taskID, selection);
                                updateSubMenuIsRunning = false;
                            }
                            else
                            {
                                Console.WriteLine("Please select a valid option");
                            }


                        }
                        break;
                }
            }
        }

        public static void CreateTask(int userId)
        {
            bool createTaskIsRunning = true;
            while (createTaskIsRunning)
            {
                // Select date
                Console.Clear();
                Console.WriteLine("Enter 1 to use existing date");
                Console.WriteLine("Enter 2 to enter new date");
                Console.WriteLine("Enter 0 to return to menu");
                int input = Validation.TwoOptionValdation();

                if (input != 0)
                {
                    int dateID = Menu.CreateOrSelectDate(userId, input);

                    bool statusIsRunning = true;

                    while (statusIsRunning)
                    {
                        Console.Clear();
                        Console.WriteLine("The status is set to UNSTARTED");
                        Console.WriteLine("Enter 0 to go back");
                        Console.WriteLine("Enter 1 to continue");

                        int choice = Validation.TwoOptionValdation();

                        if (choice != 0)
                        {
                            int statusID = 1;
                            Console.Clear();

                            bool taskCategoryIsRunning = true;
                            while (taskCategoryIsRunning)
                            {
                                Console.Clear();
                                Console.WriteLine("Please select a catergory");
                                Menu.catergoryList();
                                Console.WriteLine("Enter 0 to go back");
                                int userChoice = Validation.GetInt();

                                if (userChoice != 0)
                                {
                                    int categoryID = userChoice;

                                    bool activtyIsRunning = true;

                                    while (activtyIsRunning)
                                    {
                                        Console.Clear();
                                        Console.WriteLine("Enter 1 to use existing activity");
                                        Console.WriteLine("Enter 2 to enter new activity");
                                        Console.WriteLine("Enter 0 to return to go back");
                                        choice = Validation.TwoOptionValdation();

                                        if (choice != 0)
                                        {
                                            int activityID = Menu.CreateOrSelectActivity(userId, choice);

                                            bool timeSpentIsRunning = true;

                                            while (timeSpentIsRunning)
                                            {
                                                Console.Clear();
                                                Console.WriteLine("Time is set to 0");
                                                Console.WriteLine("Enter 0 to go back");
                                                Console.WriteLine("Enter 1 to continue");

                                                choice = Validation.GetInt();

                                                if(choice != 0)
                                                {
                                                    Database.CreateNewTask(userId, dateID, statusID, categoryID, activityID);

                                                    Console.WriteLine("Task created!");

                                                    

                                                    timeSpentIsRunning = false;
                                                    activtyIsRunning = false;
                                                    taskCategoryIsRunning = false;
                                                    statusIsRunning = false;
                                                    createTaskIsRunning = false;

                                                }
                                                else
                                                {
                                                    timeSpentIsRunning = false;
                                                }

                                            }
                                        }
                                        else
                                        {
                                            activtyIsRunning = false;
                                        }
                                    }
                                }
                                else
                                {
                                    taskCategoryIsRunning = false;
                                }

                            }
                        }
                        else
                        {
                            statusIsRunning = false;
                        }
                        
                    }

                }
                else
                {
                    createTaskIsRunning = false;
                }

                
            }
            


        }

    }
}
