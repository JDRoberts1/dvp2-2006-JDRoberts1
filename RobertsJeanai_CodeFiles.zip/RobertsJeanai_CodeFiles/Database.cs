﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace RobertsJeanai_CodeFiles
{
    public class Database
    {
        MySqlConnection _conn = null;

        public static DataTable DatabaseConnection(string query)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.QueryDB(query);

            instance._conn.Close();

            return data;

        }

        public static DataTable DateSearch(string query, int input)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();


            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.DateQuery(query, input);

            instance._conn.Close();

            return data;
        }

        public static DataTable DescSearch(string query, int input)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();


            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.DescriptionQuery(query, input);

            instance._conn.Close();

            return data;
        }

        public static DataTable CatSearch(string query, int input)
        {

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();


            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.CategoryQuery(query, input);

            instance._conn.Close();

            return data;

        }

        public static void UpdateDatabase(int activityId, int descriptionId, int dayID, int dateID,  int timeSpent)
        {
            int dateFull = dateID;

            Database instance = new Database();

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            instance.SendToDB(activityId, descriptionId, dayID, dateID, dateFull, timeSpent);

            instance._conn.Close();

            Submenu.UserFeedback();

            Validation.PressToContinue();

        }

        void Connect()
        {
            // Connection string
            BuildConnection();

            // try to connect
            try
            {
                // uses member variable
                _conn.Open();
                Console.WriteLine(" ");
            }
            catch (MySqlException e)
            {
                string msg = "";
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                            break;
                        }
                    case 1042:
                        {
                            msg = "Cant resolve host address.\n" + _conn.ConnectionString;
                            break;
                        }
                    case 1045:
                        {
                            msg = "invalid username/password";
                            break;
                        }
                    default:
                        {
                            msg = e.ToString();
                            break;
                        }

                }

                // display the exception message outsifde the switch statement 
                Console.WriteLine(msg);
            }
        }

        void BuildConnection()
        {
            string ip = "";

            // varieties of this statement
            // forwardslash : c:\\VFW\connect.txt
            // @ symbol in front : @"c:/VFW/connect.txt"
            using (StreamReader sr = new StreamReader("C:/VFW/connect.txt"))
            {
                // set the ip variable to a readline
                // returns the ip address
                ip = sr.ReadLine();
            }

            // build the string
            // server gets ip
            // hard coded values
            string conString = $"Server={ip};";
            conString += "user id=dbsAdmin;";
            conString += "pwd=password;";
            conString += "database=JeanaiRoberts_MDV2229_Database_202006;";
            // the port
            conString += "port=8889;";

            _conn.ConnectionString = conString;
        }

        DataTable QueryDB(string query)
        {
            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;


        }

        DataTable DescriptionQuery(string query, int input)
        {
            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            adapter.SelectCommand.Parameters.Add(new MySqlParameter {ParameterName = "@activity_log.activity_description", Value = input});

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;

        }

        DataTable CategoryQuery(string query, int input)
        {
            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@activity_log.category_description", Value = input });

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;

        }

        void SendToDB(int activityId, int descriptionId, int dayID, int dateID, int dateFull, int timeSpent)
        {

            string insertQuery = $"INSERT INTO activity_log (user_id, calendar_day,  calendar_date, day_name, category_description, activity_description, time_spent_on_activity) Values (1, @calendar_day, @calendar_date, @day_name, @category_description, @activity_description, @time_spent_on_activity);";
            MySqlCommand cmd = new MySqlCommand(insertQuery, _conn);

            cmd.Parameters.AddWithValue("@calendar_day", dateID);
            cmd.Parameters.AddWithValue("@calendar_date", dateFull);
            cmd.Parameters.AddWithValue("@day_name", dayID);
            cmd.Parameters.AddWithValue("@category_description", descriptionId);
            cmd.Parameters.AddWithValue("@activity_description", activityId);
            cmd.Parameters.AddWithValue("@time_spent_on_activity", timeSpent);

            MySqlDataReader rdr = cmd.ExecuteReader();
            rdr.Close();

        }

        
        DataTable DateQuery(string query, int input)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            adapter.SelectCommand.Parameters.Add(new MySqlParameter { ParameterName = "@activity_log.calendar_date", Value = input });

            DataTable data = new DataTable();

            adapter.SelectCommand.CommandType = CommandType.Text;

            adapter.Fill(data);

            return data;
        }
    }
}
