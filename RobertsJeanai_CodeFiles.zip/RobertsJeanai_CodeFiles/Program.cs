﻿using System;

namespace RobertsJeanai_CodeFiles
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Clear();
            Console.WriteLine("What would you like to do today?");
            

            bool programIsRunning = true;
            while (programIsRunning)
            {
                Console.WriteLine("1. Enter Activity\n2. View Tracked Data\n3. Run Calculations\n4. Exit");
                string menuSelection = Validation.IsEmpty();

                switch (menuSelection)
                {
                    case "1":
                    case "enter activity":
                        {
                            Console.Clear();
                            Menu.ActivityMenu();
                            Console.Clear();
                        }
                        break;
                    case "2":
                    case "view tracked data":
                        {
                            Console.Clear();
                            Menu.ViewMenu();
                            Console.Clear();
                        }
                        break;
                    case "3":
                    case "run calculations":
                        {
                            // Calculations for evething done during the 26 months
                            Console.Clear();
                            Menu.CalculationMenu();
                            Console.Clear();
                        }
                        break;
                    case "4":
                    case "exit":
                        {
                            Console.Clear();
                            programIsRunning = false;
                        }
                        break;
                }
            }
        }
    }
}
