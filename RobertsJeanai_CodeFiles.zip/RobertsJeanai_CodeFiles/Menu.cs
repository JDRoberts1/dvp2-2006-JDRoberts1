﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobertsJeanai_CodeFiles
{
    class Menu
    {
        // view calculation menu
        public static void CalculationMenu()
        {
            //■  at least 10 calculations run and shown to the user...all of them must run a calculation from the data in the database.
            //■ 1. Back
            Console.Clear();

            bool calculationProgram = true;
            while (calculationProgram)
            {
                Calculations.listOfCalculations();
                Console.WriteLine("Please select a calculation to view");
                Console.WriteLine("Enter 0 to return to main menu");
                string input = Console.ReadLine();

                if (input != "0")
                {
                    Calculations.QueryStrings(input);
                }
                else
                {
                    calculationProgram = false;
                }

            }
        }


        // view activity menu
        public static void ViewMenu()
        {
            bool viewProgramIsRunning = true;
            while (viewProgramIsRunning)
            {
                Console.Clear();
                Console.WriteLine("How would you like to view logged activity");
                Console.WriteLine("1. Select by Date\n2. Select by Category\n3. Select by Description\n4. Back");
                string input = Validation.IsEmpty();
                switch (input)
                {
                    case "1":
                    case "select by date":
                        {
                            bool dateMenu = true;

                            while (dateMenu)
                            {
                                Submenu.DateList();
                                
                                int selctionID = Validation.GetInt();
                                
                                if (selctionID > 0)
                                {
                                    Submenu.DateSelect(selctionID);

                                    bool submenu = true;
                                    while (submenu)
                                    {
                                        
                                        Console.WriteLine("Enter 1 to enter new activity");
                                        int submenuChoice = Validation.ValidatedAnswer();

                                        if (submenuChoice == 1)
                                        {

                                            bool subMenu2 = true;
                                            while (subMenu2)
                                            {
                                                ActivityMenu();
                                                int userChoice = Validation.GetInt();

                                                if(userChoice == 1)
                                                {

                                                    subMenu2 = true;
                                                    
                                                }
                                                else
                                                {
                                                    subMenu2 = false;
                                                    submenu = false;
                                                    dateMenu = false;
                                                }
                                            }
                                           
                                        }
                                        else
                                        {
                                            submenu = false;
                                            dateMenu = false;
                                        }
                                    }
                                }
                                else
                                {
                                    dateMenu = false;
                                }
                            }

                        }
                        break;
                    case "2":
                    case "select by category":
                        {
                            Console.Clear();
                            bool cateMenu = true;

                            while (cateMenu)
                            {
                                Submenu.CategoryList();
                                int userInput = Validation.GetInt();

                                if (userInput != 0)
                                {
                                    bool submenu = true;
                                    while (submenu)
                                    {
                                        Submenu.CategorySelect(userInput);
                                        Console.WriteLine();
                                        int userChoice = Validation.SelectionValidation();

                                        if (userChoice == 0)
                                        {
                                            submenu = false;
                                            
                                        }
                                        else
                                        {
                                            submenu = false;
                                            cateMenu = false;
                                        }
                                    }
                                    
                                }
                                else
                                {
                                    cateMenu = false;
                                }
                            }
                        }
                        break;
                    case "3":
                    case "select by description":
                        {
                            Console.Clear();
                            bool descMenu = true;
                            while (descMenu)
                            {
                                // Which one would you like to view?
                                // 1-X Shows Descriptions(Pulled from database)
                                Submenu.DescriptionList();
                                int selectionID = Validation.GetInt();

                                if(selectionID != 0)
                                {
                                    bool submenu = true;
                                    while (submenu)
                                    {
                                        Submenu.DescriptionSelect(selectionID);
                                        Console.WriteLine();
                                        int userChoice = Validation.SelectionValidation();

                                        if (userChoice == 0)
                                        {
                                            submenu = false;
                                        }
                                        else
                                        {
                                            submenu = false;
                                            descMenu = false;
                                        }
                                    }
                                }
                                else
                                {
                                    descMenu = false;
                                }
                            }
                        }
                        break;
                    case "4":
                    case "back":
                        {
                            viewProgramIsRunning = false;
                        }
                        break;
                }
            }
        }

        // Enter activity Menu
        public static void ActivityMenu()
        {
            Console.Clear();
            bool activityMenu = true;
            while (activityMenu)
            {
                // list categories
                Submenu.ActivityList();
                
                int activityId = Validation.GetInt();
                if (activityId != 0m)
                {
                    bool subMenu = true;
                    while (subMenu)
                    {
                        // list descriptions
                        Submenu.DescriptionList();
                        
                        int descriptionId = Validation.GetInt();
                        if(descriptionId != 0m)
                        {

                            bool subMenu2 = true;
                            while (subMenu2)
                            {
                                // list day 
                                Submenu.DayList();
                                
                                int dayID = Validation.GetInt();

                                if(dayID != 0m)
                                {
                                    bool subMenu3 = true;
                                    

                                    while (subMenu3)
                                    {
                                        // list dates
                                        Submenu.DateList();
                                        
                                        int dateID = Validation.GetInt();

                                        if (dateID != 0m)
                                        {
                                            bool subMenu4 = true;

                                            while (subMenu4)
                                            {
                                                // time spent on activity
                                                Submenu.ActivityTime();
                                                
                                                int timeSpent = Validation.GetInt();


                                                if(timeSpent != 0m)
                                                {
                                                    // send to database
                                                    Database.UpdateDatabase(activityId, descriptionId, dayID, dateID, timeSpent);

                                                    Submenu.EnterAnotherActivity();
                                                    
                                                    int returnToMain = Validation.GetInt();

                                                    
                                                    if (returnToMain == 1)
                                                    {
                                                        subMenu4 = false;
                                                        subMenu3 = false;
                                                        subMenu2 = false;
                                                        subMenu = false;

                                                    }
                                                    else
                                                    {
                                                        subMenu4 = false;
                                                        subMenu3 = false;
                                                        subMenu2 = false;
                                                        subMenu = false;
                                                        activityMenu = false;
                                                    }
                                                }
                                                else
                                                {
                                                    subMenu4 = false;
                                                }
                                            }
                                            
                                        }
                                        else
                                        {
                                            subMenu3 = false;
                                        }
                                    }

                                }
                                else
                                {
                                    subMenu2 = false;
                                }
                            }

                        }
                        else
                        {
                            subMenu = false;
                        }
                        

                    }
                }
                else
                {
                    activityMenu = false;
                }
            }
        }
    }
}
