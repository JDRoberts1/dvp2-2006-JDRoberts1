﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace RobertsJeanai_CodeFiles
{
    class Submenu
    {
        

        // Pick A Category Of Activity:
        // 1-X<Lists Categories>(Pulled from database)
        // X+1 Back
        public static void ActivityList()
        {
            Console.Clear();
            Console.WriteLine("Pick A Category Of Activity");
            string query = "Select * FROM activity_categories;";
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;

            int counter = 1;

            // output to console
            foreach (DataRow row in rows)
            {
                 
                // the key are the columns requested information on
                Console.Write($" {counter++}: ");
                Console.Write($"{row["category_description"].ToString()}");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");

        }

        // Sub Menu
        // Pick An Activity Description:
        // 1-X<Lists Descriptions>(Pulled from database)
        // X+1 Back

        public static void DescriptionList()
        {
            Console.Clear();
            Console.WriteLine("Please select a Description");
            string query = "Select * FROM activity_descriptions;";
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            int counter = 1;

            // output to console
            foreach (DataRow row in rows)
            {
               
                // the key are the columns requested information on
                Console.Write($" {counter++}: ");
                Console.Write($"{row["activity_description"].ToString()}");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");
        }

        // Sub Menu
        // 1-26 What Date Did You Perform Activity(Format:
        // Year-Month-Date: 0000-00-00) (Pulled from database)
        // Based on the Date above, it should fill in what Month
        // Day it was(1 - 26) for the user
        // 27. Back

        public static void DateList()
        {
            Console.Clear();
            Console.WriteLine("Please select the date the activity was preformed on");
            string query = "Select * FROM tracked_calendar_dates;";
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            int counter = 1;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                Console.Write($" {counter++}: ");
                Console.Write($"{row["calendar_date"].ToString()}");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");
        }

        public static void DayList()
        {
            Console.Clear();
            Console.WriteLine("Please select the day the activity was preformed on");
            string query = "Select * FROM days_of_week;";
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            int counter = 1;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                Console.Write($" {counter++}: ");
                Console.Write($"{row["day_name"].ToString()}");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");
        }

        // Sub Menu
        // How Long Did You Perform That Activity?
        // (every 15 minutes is represented as a 0.25): (Format: 0.00)
        // 1. Back

        public static void ActivityTime()
        {
            Console.Clear();
            Console.WriteLine("How long did you preform the task 1 - 96? (1: 15 mintutes = 0.25, 96: 24 hours)");
            string query = "Select * FROM activity_times LIMIT 50;";
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            int counter = 1;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                Console.Write($" {counter++}: ");
                Console.Write($"{row["time_spent_on_activity"].ToString()}");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");

        }

        // Sub Menu
        // Provides user feedback such as “activity entered.” (Activity saved to database)
        public static void UserFeedback()
        {
            Console.WriteLine("Activity has been saved to database");
        }


        // Sub Menu
        // 1. Enter Another Activity
        // 2. Back To Main Menu

        public static void EnterAnotherActivity()
        {
            Console.Clear();
            Console.WriteLine("Enter 1 to Enter new activity");
            Console.WriteLine("Enter 2 to Return to Main Menu");
        }

        // View Tracked Data
        //○ Sub Menu
        //■ 1. Select By Date
        public static void DateSelect(int selctionID)
        {
            // Which Date Would You Like To View?
            // 1-26 Shows Dates(Pulled from database)

            string query = "SELECT tracked_calendar_dates.calendar_date, activity_descriptions.activity_description, Sum(activity_times.time_spent_on_activity) as totalTimeTracked FROM activity_log JOIN tracked_calendar_dates on activity_log.calendar_date = tracked_calendar_dates.calendar_date_id Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.calendar_date = @activity_log.calendar_date Group By activity_descriptions.activity_description;";
            DataTable data = Database.DateSearch(query, selctionID);

            
            DataRowCollection rows = data.Rows;

            // Sub Menu
            // After selecting, it shows All Activities, Total Hours TRACKED/USED, and Total Hours UNTRACKED/ NOT USED

            // output to console
            foreach (DataRow row in rows)
            {

                string activity = row["activity_description"].ToString();
                double timeTracked = Convert.ToDouble(row["totalTimeTracked"].ToString());
                double untrackedTime = 24 - timeTracked;
                string date = row["calendar_date"].ToString();
                Console.WriteLine($"Date: {date} {activity}: {timeTracked} hours tracked and {untrackedTime} hours untracked");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");


        }

        
        // 2. Select By Category
        // Sub Menu
        // Which one would you like to view?
        // 1-X Shows Categories(Pulled from database)
        public static void CategoryList()
        {
            Console.WriteLine("Which category would you like ot view?");
            string query = "Select * FROM activity_categories;";
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;

            int counter = 1;

            
            // output to console
            foreach (DataRow row in rows)
            {
                
                Console.Write($" {counter++}: ");
                Console.Write($"{row["category_description"].ToString()}");
                Console.WriteLine();
            }
            Console.WriteLine("Enter 0 to go back");
        }

        //○ Sub Menu
        //○ After selecting, it shows all activities from selected category, dates they were performed, total time per activity, and total time for the category
        // (Ex: Sleeping could have one entry per day, for X hours per day, for a total of Y hours for the month) (Pulled from database)
        //○ 1. Back
        //● X+1. Bac
        public static void CategorySelect(int selectionID)
        {
            
            string query = "SELECT tracked_calendar_dates.calendar_date, activity_descriptions.activity_description, activity_times.time_spent_on_activity FROM activity_log JOIN tracked_calendar_dates on activity_log.calendar_date = tracked_calendar_dates.calendar_date_id Join  activity_descriptions On activity_log.activity_description = activity_descriptions.activity_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.category_description = @activity_log.category_description;";
            DataTable data = Database.CatSearch(query, selectionID);

            DataRowCollection rows = data.Rows;

           
            // output to console
            foreach (DataRow row in rows)
            {
                string timeString = row["time_spent_on_activity"].ToString();

                if(timeString != "")
                {
                    Console.Write($"Date preformed: {row["calendar_date"].ToString()}");
                    Console.Write($"Activity preformed: {row["activity_description"].ToString()}");
                    Console.Write($"Time spent on activity: {timeString} ");
                }
                else
                {
                    Console.WriteLine("No data available");
                }
                
            }

            query = "Select activity_categories.category_description, activity_descriptions.activity_description, Sum(activity_times.time_spent_on_activity) as totalTime From activity_log JOIN activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id where activity_log.category_description = @activity_log.category_description Group By activity_descriptions.activity_description;";

            data = Database.CatSearch(query, selectionID);

            rows = data.Rows;

            foreach (DataRow row in rows)
            {
                double totalTime = Convert.ToDouble(row["totalTime"].ToString());

                if (totalTime == 0)
                {
                    Console.WriteLine($"No data available for {row["activity_descriptions"].ToString()}");
                }
                else
                {
                    Console.Write($"The Total time Spent on  {row["category_description"].ToString()} is {totalTime}");
                }
            }

        }

        
        //■ 3. Select By Description

        //● Sub Menu
        
        public static void DescriptionSelect(int selectionID)
        {
            
            // Sub Menu
            // After selection, it shows all activities from selected description, dates they were performed, total time per activity, and total time for the description
            // output to console
            string query = "SELECT tracked_calendar_dates.calendar_date, activity_times.time_spent_on_activity FROM activity_log JOIN tracked_calendar_dates on activity_log.calendar_date = tracked_calendar_dates.calendar_date_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = @activity_log.activity_description;";

            DataTable data = Database.DescSearch(query, selectionID);

            DataRowCollection rows = data.Rows;

            foreach (DataRow row in rows)
            {
                Console.Write($"Date preformed: {row["calendar_date"].ToString()}");
                Console.Write($"Time spent on activity: {row["time_spent_on_activity"].ToString()}");
            }
            
            query = "Select Sum(activity_times.time_spent_on_activity) as totalTime From activity_log Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = @activity_log.activity_description;";

            //DataTable data = Database.DescSearch(query2, selectionID);

            data = Database.DescSearch(query, selectionID);

            rows = data.Rows;

            foreach (DataRow row in rows)
            {
                
                double totalTime = Convert.ToDouble(row["totalTime"].ToString());

                if (totalTime == 0)
                {
                    Console.WriteLine($"No data available for {row["totalTime"].ToString()}");
                }
                else
                {
                    Console.Write($"The Total time Spent on  {row["totalTime"].ToString()} is {totalTime}");
                }
                
            }
        }

    }
}
