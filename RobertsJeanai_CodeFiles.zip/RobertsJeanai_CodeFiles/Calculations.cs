﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RobertsJeanai_CodeFiles
{
    class Calculations
    {

        // Run Calculations Class
        // at least 10 calculations run and shown to the user...all of them must run a calculation from the data in the database

        public static void listOfCalculations()
        {
            List<string> calculationMenu = new List<string>();
            calculationMenu.Add("Total time spent coding");
            calculationMenu.Add("Total time spent debugging");
            calculationMenu.Add("Total time spent seeking help on each assignment");
            calculationMenu.Add("Total time spent on social media");
            calculationMenu.Add("Total time spent recording");
            calculationMenu.Add("Total time spent at away");
            calculationMenu.Add("Total time per assignement");
            calculationMenu.Add("Category where the most time was spent this month?");
            calculationMenu.Add("Where nthe most help was need");
            calculationMenu.Add("Time breakdown of time spent creating Time Tacker app ");

            int counter = 1;
            foreach(string s in calculationMenu)
            {
                Console.WriteLine($"{counter++}: {s}");
            }
        }

        public static void QueryStrings(string input)
        {
            string query;

            switch (input)
            {
                case "1":
                    {
                        // The total time spent coding id = 2 GetTime
                        query = "Select activity_descriptions.activity_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = 2;";

                        GetDescTime(query);
                        
                    }
                    break;
                case "2":
                    {
                        // total time spent debugging id = 3 GetTime
                        query = "Select activity_descriptions.activity_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = 3;";

                        GetDescTime(query);

                    }
                    break;
                case "3":
                    {
                        // total time spent seeking help on each assignment descid = 13 GetTime
                        query = "Select activity_descriptions.activity_description, activity_categories.category_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id Join activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = 13 Group by activity_categories.category_description;";

                        GetDescTime(query);
                    }
                    break;
                case "4":
                    {
                        // Total time spent on social media id = 14 GetTime
                       query = "Select activity_descriptions.activity_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = 15;";

                        GetDescTime(query);
                    }
                    break;
                case "5":
                    {
                        // total time spent recording id = 12 GetTime
                        query = "Select activity_descriptions.activity_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_descriptions on activity_log.activity_description = activity_descriptions.activity_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.activity_description = 13;";

                        GetDescTime(query);
                    }
                    break;
                case "6":
                    {
                        // total time spent away catid = 2 GetCateTime
                        query = "Select activity_categories.category_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.category_description = 2;";

                        GetCateTime(query);
                       
                    }
                    break;
                case "7":
                    {
                        // total time per assignement 7- 23 GetCateTime
                        query = "Select activity_categories.category_description, Sum(activity_times.time_spent_on_activity) as totalTime FROM activity_log Join activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id where activity_log.category_description BETWEEN 7 and 23 GROUP BY activity_categories.category_description;";

                        GetCateTime(query);
                    }
                    break;
                case "8":
                    {
                        // what category was the most time spent this month? GetCateTime
                        query = "SELECT activity_categories.category_description, MAX(activity_times.time_spent_on_activity) AS totalTime FROM activity_log JOIN activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id Group By activity_categories.category_description;";

                        GetCateTime(query);
                    }
                    break;
                case "9":
                    {
                        HelpSearch();
                    }
                    break;
                case "10":
                    {
                        // time spent creating app GetCateTime
                        query = "SELECT activity_categories.category_description, MAX(activity_times.time_spent_on_activity) AS totalTime FROM activity_log JOIN activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id WHERE activity_categories.category_description = 12 Group By activity_log.activity_description;";

                        GetCateTime(query);
                    }
                    break;
                
            }
            

        }

        public static void GetDescTime(string query)
        {
           
            
            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                string activity = ($"{row["activity_description"].ToString()}");
                string timeString = row["totalTime"].ToString();
                Double totalTime = Validation.GetDouble(timeString); 
                Console.WriteLine($"The total time spent {activity} is {totalTime}");
                Console.WriteLine();
            }

            Validation.PressToContinue();
        }

        public static void GetCateTime(string query)
        {
            

            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                string activity = ($"{row["category_description"].ToString()}");
                double time = Convert.ToDouble(row["totalTime"].ToString());
                Console.WriteLine($"The total time spent {activity} is {time}");
                Console.WriteLine();
            }

            Validation.PressToContinue();

        }

        public static void HelpSearch()
        {
            // where did i need the most help
            string query = "SELECT activity_categories.category_description, MAX(activity_times.time_spent_on_activity) AS timeTheif FROM activity_log JOIN activity_categories on activity_log.category_description = activity_categories.category_description_id Join activity_times on activity_log.time_spent_on_activity = activity_times.activity_time_id WHERE activity_log.activity_description = 13 Group By activity_categories.category_description;";


            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;

            // output to console
            foreach (DataRow row in rows)
            {
                // acts like a dictionary so instead of index, use a key for the index
                // the key are the columns requested information on
                string assignment = ($"{row["category_description"].ToString()}");
                double time = Convert.ToDouble(row["timeTheif"].ToString());
                Console.WriteLine($"The activity that need the most help was {assignment} with {time} spent seeking help.");
                Console.WriteLine();
            }

            Validation.PressToContinue();

        }
    }
}
