﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobertsJeanai_ConvertedData
{
    class MenuClass
    {
        public static void MainMenu()
        {
            // Greet the user
            
            Console.WriteLine("Hello Admin, What would you like to do today?");

            // Create list of menu options
            List<string> mainMenuList = new List<string>();

            // Add menu options to the list
            mainMenuList.Add("Convert The Restaurant Profile Table From SQL To JSON");
            mainMenuList.Add("Showcase Our 5 Star Rating System");
            mainMenuList.Add("Showcase Our Animated Bar Graph Review System");
            mainMenuList.Add("Play A Card Game");
            mainMenuList.Add("Exit");

            // for loop to display items in the main menu
            for(int counter = 0; counter < mainMenuList.Count; counter++)
            {
                Console.WriteLine($"{counter + 1}: {mainMenuList[counter]}");
            }

        }

        public static void ShowcaseMenu()
        {
            // Rating menu options
            // Create list of menu options
            List<string> ratingMenuList = new List<string>();

            // Add menu options to the list
            ratingMenuList.Add("List Restaurants Alphabetically (Show Rating Next To Name)");
            ratingMenuList.Add("List Restaurants in Reverse Alphabetical (Show Rating Next To Name)");
            ratingMenuList.Add("Sort Restaurants From Best to Worst (Show Rating Next To Name)");
            ratingMenuList.Add("Sort Restaurants From Worst to Best (Show Rating Next To Name)");
            ratingMenuList.Add("Show Only X and Up");
            ratingMenuList.Add("Return to main menu");

            // for loop to display items in the Showcase menu
            for (int counter = 0; counter < ratingMenuList.Count; counter++)
            {
                Console.WriteLine($"{counter + 1}: {ratingMenuList[counter]}");
            }

        }

        public static void ShowcaseSubMenu()
        {

            // sub menu
            List<string> ratingMenuSubList = new List<string>();
            ratingMenuSubList.Add("Show the Best(5 Stars)");
            ratingMenuSubList.Add("Show 4 Stars and Up");
            ratingMenuSubList.Add("Show 3 Stars and Up");
            ratingMenuSubList.Add("Show the Worst (1 Stars)");
            ratingMenuSubList.Add("Show Unrated");
            ratingMenuSubList.Add("Return to rating menu");

            // for loop to display items in the sub menu
            for (int counter = 0; counter < ratingMenuSubList.Count; counter++)
            {
                Console.WriteLine($"{counter + 1}: {ratingMenuSubList[counter]}");
            }
        }
    }

    
}
