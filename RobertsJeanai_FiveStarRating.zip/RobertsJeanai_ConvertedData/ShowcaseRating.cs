﻿using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;

namespace RobertsJeanai_ConvertedData
{
    class ShowcaseRating
    {
        MySqlConnection _conn = null;

        public static void ShowRating()
        {
            // New istance of the class
            ShowcaseRating instance = new ShowcaseRating();

            // set an instance of the connection
            instance._conn = new MySqlConnection();

            // call the Connect Function which calss the Build Connection funstion inside
            instance.Connect();

            instance._conn.Close();

            // Greet the user
            Console.WriteLine("Please enter your name");
            string userName = Validation.IsEmpty();

            Console.WriteLine($"Hello {userName}, How would you like to sort the data");

            string query = "";
            bool programIsRunning = true;
            while (programIsRunning)
            {
                MenuClass.ShowcaseMenu();
                Console.WriteLine("Please select an option");
                string input = Validation.IsEmpty();

                switch (input)
                {
                    case "1":
                    case "list restaurants alphabetically":
                        {

                            // list ratings by restaurant name alphabetically 
                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles Order By RestaurantName ASC;";
                            DataTable data = instance.DBQuery(query);

                            Console.Clear();
                            instance.DisplayResults(data);

                            
                            break;
                        }

                    case "2":
                    case "list restaurants reverse alphabetical":
                        {
                            // list ratings by restaurant name reverse alphabetical
                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles Order By RestaurantName DESC;";
                            DataTable data = instance.DBQuery(query);

                            Console.Clear();
                            instance.DisplayResults(data);
                            break;

                        }
                        
                    case "3":
                    case "sort restaurants from best to worst":
                        {
                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles Order By OverallRating DESC;";
                            DataTable data = instance.DBQuery(query);


                            // display data 
                            Console.Clear();
                            instance.DisplayResults(data);
                            break;
                        }
                        
                    case "4":
                    case "sort restaurants from worst to best":
                        {
                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles Order By OverallRating ASC;";
                            DataTable data = instance.DBQuery(query);

                            Console.Clear();
                            instance.DisplayResults(data);
                            break;
                        }
                        
                    case "5":
                    case "show only x and up":
                        {
                            bool submenu = true;
                            while (submenu)
                            {
                                MenuClass.ShowcaseSubMenu();
                                Console.WriteLine("Please select an option");
                                string userOption = Validation.IsEmpty();

                                switch (userOption)
                                {
                                    case "1":
                                    case "show the best":
                                        {
                                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles WHERE OverallRating = '5.00';";
                                            DataTable data = instance.DBQuery(query);

                                            Console.Clear();
                                            instance.DisplayResults(data);
                                            
                                            break;
                                        }
                                        
                                    case "2":
                                    case "show 4 stars and up":
                                        {
                                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles WHERE OverallRating >= '4.00' ORDER BY OverallRating DESC;";
                                            DataTable data = instance.DBQuery(query);

                                            // display data 
                                            Console.Clear();
                                            instance.DisplayResults(data);
                                            break;
                                        }
                                        
                                    case "3":
                                    case "show 3 stars and up":
                                        {
                                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles WHERE OverallRating >= '3.00' ORDER BY OverallRating DESC;";
                                            DataTable data = instance.DBQuery(query);


                                            // display data 
                                            Console.Clear();
                                            instance.DisplayResults(data);
                                            break;
                                        }
                                        
                                    case "4":
                                    case "show the worst":
                                        {
                                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles WHERE OverallRating = '1.00';";
                                            DataTable data = instance.DBQuery(query);
                                            Console.Clear();

                                            // display data 
                                            Console.Clear();
                                            instance.DisplayResults(data);

                                            break;
                                        }
                                        
                                    case "5":
                                    case "show unrated":
                                        {
                                            query = "Select RestaurantName, OverallRating FROM RestaurantProfiles WHERE OverallRating is NULL;";

                                            Console.Clear();
                                            DataTable data = instance.DBQuery(query);


                                            // display data 
                                            Console.Clear();
                                            instance.DisplayResults(data);
                                            break;
                                        }
                                        
                                    case "6":
                                    case "back":
                                        {

                                            Console.Clear();
                                            Console.WriteLine("Enter 1 to Return to menu\nEnter 2 to return to Showcase menu");
                                            string option = Console.ReadLine();
                                            int userChoice;
                                            userChoice = Validation.GetInt(option);

                                            if(userChoice == 1)
                                            {
                                                Validation.ResortData();
                                            }
                                            else
                                            {
                                                submenu = false;
                                                Validation.ReturnToMain();
                                            }
                                            break;
                                        }
                                        


                                }
                            }
                        }
                        break;

                    case "6":
                    case "exit":
                        {
                            Console.Clear();
                            programIsRunning = false;
                        }
                        break;
                }
            }
        }

        // Build connection method
        void BuildConnection()
        {
            // set variable for ipAddress
            string ip = "";

            // pull ip address from the file
            using (StreamReader sr = new StreamReader("c:/VFW/connect.txt"))
            {
                ip = sr.ReadLine();
            }

            // Hard coded login
            string conString = $"Server={ip};";
            conString += "user id = dbsAdmin;";
            conString += "password = password;";
            conString += "database=SampleRestaurantDatabase;";
            conString += "port=8889;";

            _conn.ConnectionString = conString;
        }

        // Connect to the database
        void Connect()
        {
            // connection string
            BuildConnection();

            // try to connect
            try
            {
                _conn.Open();
                Console.WriteLine("Connection Successful");
            }
            // display exception error if something goes wrong
            catch (MySqlException e)
            {
                string msg = "";
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                            break;
                        }
                    case 1042:
                        {
                            msg = "Cant resolve host address.\n" + _conn.ConnectionString;
                            break;
                        }
                    case 1045:
                        {
                            msg = "invalid username/password";
                            break;
                        }
                    default:
                        {
                            msg = e.ToString();
                            break;
                        }
                }

                Console.WriteLine(msg);
            }

        }

        // build data table from information returned from query
        DataTable DBQuery(string query)
        {
            // Create connection with connection string and query 
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            // create the data table
            DataTable data = new DataTable();

            adapter.SelectCommand.CommandType = CommandType.Text;

            // fill the table with the returned information
            adapter.Fill(data);

            // return datatable to Main method in this class
            return data;
        }

        void DisplayResults(DataTable data)
        {
            DataRowCollection rows = data.Rows;
            decimal rating;
           
            // display data 
            foreach (DataRow row in rows)
            {

                string name = row["RestaurantName"].ToString();
                string ratingString = row["OverallRating"].ToString();


                if (ratingString != "")
                {

                    rating = Convert.ToDecimal(row["OverallRating"].ToString());
                    rating = Math.Round(rating, MidpointRounding.ToEven);

                    DrawStars.DisplayStars(name, rating);
                    
                }
                else
                {
                    rating = 0m;
                    DrawStars.DisplayStars(name, rating);
                }
            }
        }

        
    }
    
}
