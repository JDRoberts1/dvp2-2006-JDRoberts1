﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobertsJeanai_ConvertedData
{
    class DrawGraph
    {
        public static void DrawBarGraph(string restaurantName, double rating)
        {
            // Bad(Red) = 30 or less positive reviews
            // Average(Yellow) = 31 to 69 positive reviews
            // Good(Green) = 70 or more positive reviews
            // Total Number of Restaurants In Database = 100
            // Total Reviews Per Restaurant = 100

            // Total Possible Review Score (Total Bar Graph Size) = 100
            //If "100" is too large for the bar graph(console width), use math to scale it down to "10" accordingly.


            if(rating != 0)
            {
                if (rating <= 30)
                {
                    if (rating <= 29)
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.Write("     ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write("                                     ");
                        Console.ResetColor();

                    }
                    else
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.Write("         ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write("                         ");
                        Console.ResetColor();
                    }
                    Console.WriteLine();
                }
                else if (rating <= 69)
                {

                    if (rating <= 49)
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        Console.Write("             ");
                        Console.ResetColor();
                        Console.ForegroundColor = ConsoleColor.Gray;
                        Console.Write("                     ");
                        Console.ResetColor();
                    }
                    else if (rating <= 59)
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.Write("                 ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write("                 ");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Yellow;
                        Console.Write("                     ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write("             ");
                        Console.ResetColor();
                    }
                    Console.WriteLine();
                }

                else if (rating >= 70)
                {

                    if (rating <= 79)
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.Write("                         ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write("         ");
                        Console.ResetColor();
                    }
                    else if (rating <= 89)
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.Write("                             ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write("     ");
                        Console.ResetColor();
                        Console.WriteLine();
                    }
                    else
                    {
                        Console.Write(restaurantName + ": " + rating + "/100 ");
                        Console.BackgroundColor = ConsoleColor.Green;
                        Console.Write("                                 ");
                        Console.ResetColor();
                        Console.BackgroundColor = ConsoleColor.Gray;
                        Console.Write(" ");
                        Console.ResetColor();
                    }
                    Console.WriteLine();
                }
                else
                {
                    Console.Write(restaurantName + ": " + rating + "/100 ");
                    Console.BackgroundColor = ConsoleColor.Green;
                    Console.Write("                                     ");
                    Console.ResetColor();

                }
                Console.WriteLine();
            }
            else
            {
                Console.Write(restaurantName);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(" No rating available\n");

                Console.ResetColor();
            }
            Console.WriteLine();
        }
    }
}
