﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RobertsJeanai_ConvertedData
{
    class DrawStars
    {
        public static void DisplayStars(string restaurantName, decimal rating)
        {

            if (rating == 1m)
            {
                Console.Write(restaurantName + ": " + rating + "/5 ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("*");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("****\n");
                Console.ResetColor();


            }
            else if (rating == 2m)
            {
                Console.Write(restaurantName + ": " + rating + "/5 ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write("**");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("***\n");
                Console.ResetColor();
            }
            else if (rating == 3m)
            {
                Console.Write(restaurantName + ": " + rating + "/5 ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("***");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("**\n");
                Console.ResetColor();
            }
            else if (rating == 4m)
            {
                Console.Write(restaurantName + "Rating: " + rating + "/5 ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("****");
                Console.ResetColor();
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.Write("*\n");
                Console.ResetColor();
            }
            else if (rating == 5m)
            {
                Console.Write(restaurantName + "Rating: " + rating + "/5 ");
                Console.ForegroundColor = ConsoleColor.Green;
                Console.Write("*****\n");

                Console.ResetColor();

            }
            else
            {
                Console.Write(restaurantName);
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write(" No rating available\n");

                Console.ResetColor();
            }
        }
    }
}
