﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace RobertsJeanai_ConvertedData
{
    class Database
    {
        MySqlConnection _conn = null;

        public static DataTable DatabaseConnection(string query)
        {

            Database instance = new Database();
            

            instance._conn = new MySqlConnection();
            instance.Connect();

            // inside the parethese SELECT the columns of data to be returned.
            DataTable data = instance.QueryDB(query);

            instance._conn.Close();

            return data;

        }

        void Connect()
        {
            // Connection string
            BuildConnection();

            // try to connect
            try
            {
                // uses member variable
                _conn.Open();
               
            }
            catch (MySqlException e)
            {
                string msg;
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                            break;
                        }
                    case 1042:
                        {
                            msg = "Cant resolve host address.\n" + _conn.ConnectionString;
                            break;
                        }
                    case 1045:
                        {
                            msg = "invalid username/password";
                            break;
                        }
                    default:
                        {
                            msg = e.ToString();
                            break;
                        }

                }

                // display the exception message outsifde the switch statement 
                Console.WriteLine(msg);
            }
        }

        void BuildConnection()
        {
            string ip = "";

            // varieties of this statement
            // forwardslash : c:\\VFW\connect.txt
            // @ symbol in front : @"c:/VFW/connect.txt"
            using (StreamReader sr = new StreamReader("C:/VFW/connect.txt"))
            {
                // set the ip variable to a readline
                // returns the ip address
                ip = sr.ReadLine();
            }

            // build the string
            // server gets ip
            // hard coded values
            string conString = $"Server={ip};";
            conString += "user id=dbsAdmin;";
            conString += "pwd=password;";
            conString += "database=SampleRestaurantDatabase;";
            // the port
            conString += "port=8889;";

            _conn.ConnectionString = conString;
        }

        DataTable QueryDB(string query)
        {
            // executes the query and returns data back
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _conn);

            // need a datatable to return
            DataTable data = new DataTable();

            // tell how to execute the command
            adapter.SelectCommand.CommandType = CommandType.Text;

            // executes the query and puts the data retuned in the data table
            adapter.Fill(data);

            return data;


        }
    }
}
