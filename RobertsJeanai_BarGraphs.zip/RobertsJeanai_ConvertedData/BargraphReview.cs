﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RobertsJeanai_ConvertedData
{
    class BargraphReview
    {
        public static void Bargarph()
        {
            bool programIsRunning = true;

            while (programIsRunning)
            {
                MenuClass.BarGraphMenu();
                Console.WriteLine("Please select an option");
                string input = Validation.IsEmpty();
                string query;

                switch (input)
                {
                    case "1":
                    case "Show Average of Reviews for Restaurants":
                        {
                            Console.Clear();
                            query = "Select RestaurantName, AVG (ReviewScore) AS AVGRating FROM RestaurantReviews Join RestaurantProfiles ON RestaurantReviews.RestaurantID = RestaurantProfiles.id Group By RestaurantName;";
                            DisplayReviewRating(query);
                            Validation.ResortData();

                            Console.Clear();
                            break;
                        }
                    case "2":
                    case "Sinner Spinner (Selects Random Restaurant)":
                        {
                            bool randomSubMenu = true;

                            while (randomSubMenu)
                            {
                                Console.Clear();
                                query = "Select RestaurantName, AVG (ReviewScore) AS AVGRating FROM RestaurantReviews Join RestaurantProfiles ON RestaurantReviews.RestaurantID = RestaurantProfiles.id Group By RestaurantName ORDER BY RAND() LIMIT 1;";
                                DisplayReviewRating(query);
                                Console.WriteLine();
                                Console.WriteLine("Enter 1  to dipaly new restruant");
                                Console.WriteLine("Enter 0 to return to menu");
                                string userInput = Console.ReadLine();
                                int user = Validation.GetInt(userInput);

                                if (user == 1)
                                {
                                    DisplayReviewRating(query);
                                }
                                else
                                {
                                    randomSubMenu = false;
                                }

                                Console.Clear();
                            }
                            break;
                        }
                    case "3":
                    case "Top 10 Restaurants":
                        {
                            Console.Clear();
                            query = "Select RestaurantName, AVG (ReviewScore) AS AVGRating FROM RestaurantReviews Join RestaurantProfiles ON RestaurantReviews.RestaurantID = RestaurantProfiles.id Group By RestaurantName Order by AVGRating DESC LIMIT 10;";
                            DisplayReviewRating(query);
                            Validation.ReturnToMain();
                            Console.Clear();
;                            break;
                        }
                    case "4":
                    case "Back To Main Menu":
                        {
                            Console.Clear();
                            programIsRunning = false;
                            
                            
                        }
                        break;

                }
            }
        }

        public static void DisplayReviewRating(string query)
        {
            

            DataTable data = Database.DatabaseConnection(query);

            DataRowCollection rows = data.Rows;
            double rating;

            // display data 
            foreach (DataRow row in rows)
            {

                string name = row["RestaurantName"].ToString();
                string ratingString = row["AVGRating"].ToString();


                if (ratingString != "")
                {

                    rating = Convert.ToDouble(row["AVGRating"].ToString());
                    rating = Math.Round(rating, MidpointRounding.ToEven);

                    // SEND TO DRAW BAR CLASS
                    DrawGraph.DrawBarGraph(name, rating);

                }
                else
                {
                    rating = 0;

                    DrawGraph.DrawBarGraph(name, rating);
                }
            }

        }

        
        
    }
}
