﻿using System;

namespace RobertsJeanai_ConvertedData
{
    class Program
    {
        static void Main(string[] args)
        {
            // verify code works on MAC

            //Database Location
            //string cs = @"server= 127.0.0.1;userid=root;password=root;database=SampleRestaurantDatabase;port=8889";

            //Output Location
            //string _directory = @"../../output/";

            Console.WriteLine("Please enter your name");
            string userName = Validation.IsEmpty();
            Console.Clear();
           

            bool programIsRunning = true;
            while (programIsRunning)
            {
                MenuClass.MainMenu();
                Console.WriteLine("Please select an option");
                string userOption = Validation.IsEmpty();

                switch (userOption)
                {
                    case "1":
                    case "convert the restaurant profile table from sql to json":
                        {
                            Console.Clear();

                            // Call the Convert class
                            JSONConvert.ConvertJSON();

                            Console.Clear();
                        }
                        break;
                    case "2":
                    case "showcase our 5 star rating system":
                        {
                            Console.Clear();

                            // Greet the user
                            Console.WriteLine($"Hello {userName}, How would you like to sort the data");

                            // Call showcase class
                            ShowcaseRating.ShowRating();

                            Console.Clear();
                        }
                        break;
                    case "3":
                    case "showcase our animated bar graph review system":
                        {
                            Console.Clear();

                            Console.WriteLine($"Hello {userName}, How would you like to sort the data?");
                            BargraphReview.Bargarph();

                            Console.Clear();
                        }
                        break;
                    case "4":
                    case "play a card game":
                        {

                        }
                        break;
                    case "5":
                    case "exit":
                        {
                            Console.Clear();
                            programIsRunning = false;
                        }
                        break;
                }
                
            }
            

        }
    }
}
